import React, { useState, useEffect } from 'react';
import ExamSetupForm from './components/ExamSetupForm';
import './App.css';
import moment from "moment-timezone";

import uniLogo from './assets/img/uni-logo1.JPG';
import thirtyMinImage from './assets/img/30min.jpg';
import thirtyMinImage1 from './assets/img/walk2.png';

function App() {
    const [examData, setExamData] = useState(false);
    const [remainingTime, setRemainingTime] = useState(null);
    const [examStarted, setExamStarted] = useState(false);
    const [popupMessage, setPopupMessage] = useState('');
    const [toastMessage, setToastMessage] = useState('');
    const [showForm, setShowForm] = useState(false);
    const [showPopup, setShowPopup] = useState(false); // State for showing the student count popup
    const [totalStudents, setTotalStudents] = useState(0); // State for total students appeared
    const [teacherName, setTeacherName] = useState('');
    const [examTimeLabel, setExamTimeLabel] = useState('Time to Start Exam');

    const [showExamStopModal, setShowExamStopModal] = useState(false);
    const [stopExamreason, setStopExamreason] = useState('');

    const [showExtendTimeModal, setShowExtendTimeModal] = useState(false);
    const [updatedTotalTime, setUpdatedTotalTime] = useState('');
    const [examEnd, setExamEnd] = useState(false);

    // const [remainingTime, setRemainingTime] = useState(totalTime * 60); // totalTime in minutes converted to seconds
    const [showRedBanner, setShowRedBanner] = useState(false);
    const [showGreenBanner, setShowGreenBanner] = useState(false);

    useEffect(() => {
        let interval;
        if (examData && !examStarted) {
            interval = setInterval(() => {
                const now = new Date();
                const start = new Date(examData.actualStartTime);
                const end = new Date(start.getTime() + examData.totalTime * 60000); // Calculate end time

                const remaining = Math.floor((start - now) / 1000); // Time in seconds

                if (remaining <= 0) {
                    setExamStarted(true);
                    setRemainingTime(Math.floor((end - now) / 1000));
                    showPopupMessage('Exam Started!', 5000); // Show for 5 seconds
                    setExamTimeLabel('Remaining Time');
                } else {
                    setRemainingTime(remaining);
                    setExamTimeLabel('Time to Start Exam');
                }
            }, 1000);
        } else if (examData && examStarted) {
            interval = setInterval(() => {
                const now = new Date();
                const end = new Date(new Date(examData.actualStartTime).getTime() + examData.totalTime * 60000); // Calculate end time

                const remaining = Math.floor((end - now) / 1000); // Time in seconds
                setRemainingTime(remaining > 0 ? remaining : 0);

                if (remaining <= 0) {
                    // Clear the interval immediately to prevent further updates
                    clearInterval(interval);

                    // Show "Time Up!" message
                    showPopupMessage('Time Up!', 5000); // Show for 5 seconds

                    // Wait for a brief period before showing the form
                    setExamEnd(true);
                    setShowRedBanner(false);
                    setShowGreenBanner(false);
                    setTimeout(() => {
                        setShowForm(true); // Show form on time up
                    }, 3000); // Wait 5 seconds after "Time Up!" message
                }

                 // Determine if first 30 minutes or last 30 minutes
                const first30Minutes = 30 * 60; // 30 minutes in seconds
                const last30Minutes = examData.totalTime * 60 - (30 * 60); // 30 minutes before the end in seconds

                if (remaining <= first30Minutes || remaining >= last30Minutes) {
                    setShowRedBanner(true);
                    setShowGreenBanner(false);
                } else {
                    setShowRedBanner(false);
                    setShowGreenBanner(true);
                }

            }, 1000);
        }

        return () => clearInterval(interval);
    }, [examData, examStarted]);

    

    const handleExamSetup = (data) => {
        setExamData(data);
        setExamStarted(false);
        setRemainingTime(null);
    };

    const showPopupMessage = (message, duration) => {
        setPopupMessage(message);
        setTimeout(() => {
            setPopupMessage('');
        }, duration); // Display message for specified duration
    };

    const handleAttendanceSubmit = () => {
        // Here you can handle the submission logic (e.g., sending data to backend)
        setShowForm(false); // Hide the form after submission
        setExamEnd(true);
        setShowRedBanner(false);
        setShowGreenBanner(false);
        setToastMessage('Exam Conducted Successfully!');
        setTimeout(() => {
            setToastMessage('');
            setShowPopup(true); // Show popup after 4 seconds
        }, 4000);
    };

    const handlePopupSubmit = async (event) => {
        event.preventDefault();
        window.location.reload();
        console.log('innn API call fun');
        const dto = {
            examCode: examData.examCode,
            examName: examData.examName,
            assignedStartDateTime: examData.startTime,
            actualStartDateTime: examData.actualStartTime,
            assignedEndDateTime: examData.endTime,
            actualEndDateTime: moment().toISOString(),
            totalTime: examData.totalTime,
            totalStudentsAppeared: totalStudents,
            teacherName: teacherName,
            stopExamReason: stopExamreason,
            reasonOfStoppingExam: examData.reasonOfStoppingExam,
            reasonOfChangingEndTime: examData.reasonOfChangingEndTime,
            wasTimeExtended: examData.wasTimeExtended,
            was30MinuteRuleImplemented: examData.was30MinuteRuleImplemented,
            additionalRules: examData.rules,
            basicRules: examData.basicRules,
            combinedRules: examData.combinedRules,
        };

        const apiUrl = 'http://localhost:8080/api/v1/add-data';

        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(dto),
            });
    
            if (!response.ok) {
                throw new Error(`Network response was not ok: ${response.statusText}`);
            }
    
            const data = await response.json();
            console.log('Success:', data);
    
            // Reset states after successful submission
            setShowPopup(false);
            setExamData(null);
            setTotalStudents(0);
    
            // Optionally show success message to the user
        } catch (error) {
            console.error('Error:', error);
            // Optionally show error message to the user
        }
    };

    const formatTime = (seconds) => {
        const hours = Math.floor(seconds / 3600);
        const mins = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        let timeString = '';

        if (hours > 0) {
            timeString += `${hours} hr `;
        }

        if (mins > 0) {
            timeString += `${mins} min `;
        }

        timeString += `${secs} sec`;

        return timeString.trim();
    };

    const formatDate = (date) => {
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return new Date(date).toLocaleDateString(undefined, options);
    };

    const handleExamStopShowModal = () => {
        setShowExamStopModal(true);
    };
    const handleExamStopHideModal = () => {
        setShowExamStopModal(false);
    };
    const handleExamStopModalSubmit = (event) => {
        console.log(stopExamreason); // Handle your submit logic here
        setShowExamStopModal(false);
        handlePopupSubmit(event);
        setShowPopup(false);
        setExamData(null);
        setTotalStudents(0);
        showPopupMessage(null);
    };

    const handleExtendTimeShowModal = () => {
        setShowExtendTimeModal(true);
    };

    const handleExtendTimeHideModal = () => {
        setShowExtendTimeModal(false);
    };

    const updateTotalTime = () => {
        if(!updatedTotalTime || updatedTotalTime < 1) return;
        setExamData((prevData) => ({
            ...prevData,
            totalTime: updatedTotalTime
        }));
        setExamStarted(false);
        setRemainingTime(null);
        setShowExtendTimeModal(false);
        setUpdatedTotalTime('');
    };

    const handleExtendTimeModalSubmit = () => {
       
    };

    return (
        <div className="App">
             <div className="container-fluid">
                <div className="row">
                    <div className="col-6 min-vh-100 d-flex flex-column justify-content-center align-items-center">
                        <img src={uniLogo} alt="Uni Logo" className="img-fluid" style={{ maxHeight: '100%', maxWidth: '100%' }} />
                        <h1>Exam Management System</h1>
                        {examData && examData.was30MinuteRuleImplemented && (
                            <img src={thirtyMinImage} alt="30 Minutes Image" className="img-fluid mt-3" style={{ maxHeight: '800%', maxWidth: '800%' }} />
                        )}
                        {examData && examData.was30MinuteRuleImplemented === false && (
                            <img src={thirtyMinImage1} alt="30 Minutes Image" className="img-fluid mt-3" style={{ maxHeight: '800%', maxWidth: '800%' }} />
                        )}
                    </div>
                    <div className="col-6">
                    <div>
                        {popupMessage && (
                            <div className="popup">
                                <div className="container py-4">
                                    <div className="row justify-content-center">
                                        <div className="col-md-6">
                                        <div className="card popup-banner-color shadow-sm text-center">
                                            <div className="card-body">
                                            <h4 className="card-title text-danger mb-4">Important Message</h4>
                                            <h2 className="fw-bold">{popupMessage}</h2>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                        {toastMessage && (
                            <div className="toast">
                                <p>{toastMessage}</p>
                            </div>
                        )}
                        {!examData ? (
                            <ExamSetupForm onExamSetup={handleExamSetup} />
                        ) : (
                            <div>                               
                                <div className="container py-4">
                                    {!examEnd && (
                                        <div>
                                            {showRedBanner && examData.was30MinuteRuleImplemented === true && <div className="banner red text-center">Student can't leave the exam hall.</div>}
                                            {showGreenBanner && <div className="banner green text-center">Student can leave the exam hall.</div>}
                                        </div>
                                    )}
                                    <div className="card shadow-sm mt-3">
                                        <div className="card-body">
                                            <h2 className="card-title text-center">Exam Details</h2>
                                        </div>
                                        <div className="card-body">


                                            <hr/>
                                            <div className="mb-3">
                                                <div><h2 className="d-inline">{examTimeLabel}:</h2> <span className="font-22">{formatTime(remainingTime)}</span></div>
                                            </div>
                                            <hr/>
                                        
                                            <div className="mb-3">
                                                <div><strong>Exam Code:</strong> <span >{examData.examCode}</span></div>
                                            </div>
                                            
                                            <div className="mb-3">
                                                <div><strong>Exam Name:</strong> <span >{examData.examName}</span></div>
                                            </div>
                                            
                                            <div className="mb-3">
                                                <div><strong>Start Time:</strong> <span >{new Date(examData.actualStartTime).toLocaleTimeString()}</span></div>
                                            </div>
                                            
                                            <div className="mb-3">
                                                <div><strong>End Time:</strong> <span>{new Date(new Date(examData.actualStartTime).getTime() + examData.totalTime * 60000).toLocaleTimeString()}</span></div>
                                            </div>

                                            <div>
                                                <div><strong>Basic Rules:</strong></div>
                                                <pre className="bg-light p-3 rounded">
                                                    <p>1. Students must arrive 15 minutes before the exam.</p>
                                                    <p>2. No talking during the exam.</p>
                                                    <p>3. No leaving the exam room without permission.</p>
                                                </pre>
                                            </div>
                                            <div>
                                                <div><strong>Additional Rules:</strong></div>
                                                <pre className="bg-light p-3 rounded">{examData.rules}</pre>
                                            </div>
                                            <div className="row">
                                                <div className="col d-flex justify-content-end">
                                                    {!examEnd && (
                                                        <div>
                                                            <button type="button" className="btn btn-primary me-2" onClick={handleExtendTimeShowModal}>Extend Time</button>
                                                            <button type="button" className="btn btn-danger" onClick={handleExamStopShowModal}>Stop Exam</button>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                        {showForm && (
                            <div>
                                <div className="container py-4">
                                    <div className="card shadow-sm">
                                        <div className="card-body">
                                        <h2 className="card-title text-center mb-2">Attendance Form</h2>
                                        <form>
                                            <div className="form-check mb-3">
                                                <input 
                                                    className="form-check-input" 
                                                    type="checkbox" 
                                                    id="attendance" 
                                                    name="attendance" 
                                                />
                                                <label className="form-check-label" htmlFor="attendance">
                                                    Mark Attendance
                                                </label>
                                                </div>
                                                <div>
                                                <button type="button" className="btn btn-secondary" 
                                                    onClick={handleAttendanceSubmit}> Submit</button>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                        {showPopup && (
                            <div className="popup">
                                <div className="container py-4">
                                    <div className="card shadow-sm">
                                        <div className="card-body">
                                        <h2 className="card-title text-center mb-3">Enter Total Students Appeared</h2>
                                        <form onSubmit={handlePopupSubmit}>
                                        <div className="mb-3">
                                                <label htmlFor="teacherName" className="form-label">
                                                    Invigilator Name:
                                                </label>
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    id="teacherName"
                                                    value={teacherName}
                                                    onChange={(e) => setTeacherName(e.target.value)}
                                                    required
                                                />
                                            </div>
                                            <div className="mb-3">
                                                <label htmlFor="totalStudents" className="form-label">
                                                    Total Students:
                                                </label>
                                                <input
                                                    type="number"
                                                    className="form-control"
                                                    id="totalStudents"
                                                    value={totalStudents}
                                                    onChange={(e) => setTotalStudents(Number(e.target.value))}
                                                    min="0"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <button type="submit" className="btn btn-secondary">OK</button>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                 </div>
                            </div>
                        )}                         
                         {showExamStopModal && (
                            <div className="modal show d-block" tabIndex="-1" role="dialog">
                                <div className="modal-dialog" role="document">
                                    <div className="modal-content">
                                        <div className="modal-header">
                                            <h5 className="modal-title">Stop Exam</h5>
                                            <button type="button" className="btn-close" onClick={handleExamStopHideModal}></button>
                                        </div>
                                        <div className="modal-body">
                                            <div className="mb-3">
                                                <label htmlFor="messageTextarea" className="form-label">Reason:</label>
                                                <textarea
                                                    id="messageTextarea"
                                                    className="form-control"
                                                    rows="4"
                                                    value={stopExamreason}
                                                    onChange={(e) => setStopExamreason(e.target.value)}
                                                />
                                            </div>
                                        </div>
                                        <div className="modal-footer">
                                            <button type="button" className="btn btn-secondary" onClick={handleExamStopHideModal}>Close</button>
                                            <button type="button" className="btn btn-primary" onClick={handleExamStopModalSubmit}>Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                        {showExtendTimeModal && (
                            <div className="modal show d-block" tabIndex="-1" role="dialog">
                                <div className="modal-dialog" role="document">
                                    <div className="modal-content">
                                        <div className="modal-header">
                                            <h5 className="modal-title">Chnage Exam Time</h5>
                                            <button type="button" className="btn-close" onClick={handleExtendTimeHideModal}></button>
                                        </div>
                                        <div className="modal-body">
                                            <div className="mb-3">
                                                <input
                                                    type="number"
                                                    className="form-control"
                                                    placeholder="Enter Time"
                                                    value={updatedTotalTime}
                                                    onChange={(e) => setUpdatedTotalTime(e.target.value)}
                                                    required
                                                    min={1}
                                                />
                                            </div>
                                        </div>
                                        <div className="modal-footer">
                                            <button type="button" className="btn btn-secondary" onClick={handleExtendTimeHideModal}>Close</button>
                                            <button type="button" className="btn btn-primary" onClick={updateTotalTime}>Submit</button>
                                            {/* <button type="button" className="btn btn-primary" onClick={handleExtendTimeModalSubmit}>Submit</button> */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                    </div>
                </div>
            </div>
            
        </div>
    );
}

export default App;
