import React, { useState, useEffect } from 'react';
import moment from 'moment-timezone';

function ExamSetupForm({ onExamSetup }) {
    const [examCode, setExamCode] = useState('');
    const [examName, setExamName] = useState('');
    const [startDate, setStartDate] = useState('');
    const [startTime, setStartTime] = useState('');
    const [actualStartTime, setActualStartTime] = useState('');
    const [timeZone] = useState(moment.tz.guess());
    const [totalTime, setTotalTime] = useState('');
    const [rules, setRules] = useState('');
    const [refrainStudents, setRefrainStudents] = useState(false);

    useEffect(() => {
        const currentDateTime = moment().tz(moment.tz.guess());
        setStartDate(currentDateTime.format('YYYY-MM-DD'));
        setStartTime(currentDateTime.format('HH:mm'));
        setActualStartTime(currentDateTime.format('HH:mm'));
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();

        const startDateTime = moment.tz(`${startDate} ${startTime}`, 'YYYY-MM-DD HH:mm', timeZone).toISOString();
        const currentActualStartDateTime = moment.tz(`${moment().format('YYYY-MM-DD')} ${actualStartTime}`, 'YYYY-MM-DD HH:mm', timeZone).toISOString();
        const endTime = moment(startDateTime).add(totalTime, 'minutes').toISOString();

        let updatedRules = rules.trim();
        if (refrainStudents) {
            updatedRules += "\nStudents are refrained from leaving in the first or last 30 minutes.";
        }

        const formData = {
            examCode,
            examName,
            startTime: startDateTime,
            actualStartTime: currentActualStartDateTime,
            endTime,
            totalTime,
            rules: updatedRules,
            was30MinuteRuleImplemented: refrainStudents,
        };

        console.log('Form Submitted:', formData);

        // Pass the formData to the onExamSetup callback
        onExamSetup(formData);
    };

    return (
        <form className="exam-setup-form" onSubmit={handleSubmit}>
            <div className="row mb-1">
                <div className="col">
                    <label htmlFor="examCode" className="form-label">Exam Code</label>
                    <input
                        type="text"
                        className="form-control"
                        id="examCode"
                        placeholder="Enter Exam Code"
                        value={examCode}
                        onChange={(e) => setExamCode(e.target.value)}
                        required
                    />
                </div>
            </div>
            <div className="row mb-1">
                <div className="col">
                    <label htmlFor="examName" className="form-label">Exam Name</label>
                    <input
                        type="text"
                        className="form-control"
                        id="examName"
                        placeholder="Enter Exam Name"
                        value={examName}
                        onChange={(e) => setExamName(e.target.value)}
                        required
                    />
                </div>
            </div>
            <div className="row mb-1">
                <div className="col">
                    <label htmlFor="startDate" className="form-label">Start Date</label>
                    <input
                        type="date"
                        className="form-control"
                        id="startDate"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        required
                    />
                </div>
            </div>
            <div className="row mb-1">
                <div className="col">
                    <label htmlFor="startTime" className="form-label">Start Time</label>
                    <input
                        type="time"
                        className="form-control"
                        id="startTime"
                        value={startTime}
                        onChange={(e) => setStartTime(e.target.value)}
                        required
                    />
                </div>
            </div>
            <div className="row mb-1">
                <div className="col">
                    <label htmlFor="actualStartDate" className="form-label">Actual Start Date</label>
                    <input
                        type="text"
                        className="form-control"
                        id="actualStartDate"
                        placeholder="YYYY-MM-DD"
                        value={moment().format('YYYY-MM-DD')} // Non-editable current date
                        readOnly
                        required
                    />
                </div>
            </div>
            <div className="row mb-1">
                <div className="col">
                    <label htmlFor="actualStartTime" className="form-label">Actual Start Time</label>
                    <input
                        type="time"
                        className="form-control"
                        id="actualStartTime"
                        placeholder="Enter Actual Start Time"
                        value={actualStartTime}
                        onChange={(e) => setActualStartTime(e.target.value)}
                        min={startTime} // Ensure actualStartTime >= startTime
                        required
                    />
                </div>
            </div>
            <div className="row mb-1">
                <div className="col">
                    <label htmlFor="totalTime" className="form-label">Total Time (minutes)</label>
                    <input
                        type="number"
                        className="form-control"
                        id="totalTime"
                        placeholder="Enter Total Time"
                        value={totalTime}
                        onChange={(e) => setTotalTime(e.target.value)}
                        required
                        min={1} // Ensure total time is greater than 0
                    />
                </div>
            </div>
            <div className="row mb-1">
                <div className="col">
                    <label htmlFor="rules" className="form-label">Additional Rules</label>
                    <textarea
                        className="form-control"
                        id="rules"
                        placeholder="Enter Additional Rules"
                        value={rules}
                        onChange={(e) => setRules(e.target.value)}
                        rows={4}
                    />
                </div>
            </div>
            <div className="row mb-1">
                <div className="col">
                    <p><strong>Basic Rules:</strong></p>
                    <p>1. Students must arrive 15 minutes before the exam.</p>
                    <p>2. No talking during the exam.</p>
                    <p>3. No leaving the exam room without permission.</p>
                    {totalTime >= 30 && (
                        <div className="form-check d-flex align-items-center">
                        <input
                            type="checkbox"
                            className="form-check-input"
                            id="refrainStudents"
                            checked={refrainStudents}
                            onChange={(e) => setRefrainStudents(e.target.checked)}
                        />
                        <label className="form-check-label ms-2" htmlFor="refrainStudents">
                            Refrain students from leaving in the first or last 30 minutes
                        </label>
                        </div>
                    )}
                </div>
            </div>

                
            <div className="row mb-3">
                <div className="col">
                    <button type="submit" className="btn btn-primary">Setup Exam</button>
                </div>
            </div>
        
        </form>
    );
}

export default ExamSetupForm;
