package com.example.exam_project_backend_java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamProjectBackendJavaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExamProjectBackendJavaApplication.class, args);
    }

}
