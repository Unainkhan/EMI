package com.example.exam_project_backend_java.controllers;

import com.example.exam_project_backend_java.dtos.ConductedExamDTO;
import com.example.exam_project_backend_java.services.ExamDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class ExamController {

    @Autowired
    private ExamDataService examDataService;

    @CrossOrigin(origins = "http://localhost:3000")
    @PostMapping("/add-data")
    public ResponseEntity<?> addExamData(@RequestBody ConductedExamDTO conductedExamDTO) {
        try {
            System.out.println("Received DTO: " + conductedExamDTO); // Add this line to log the received DTO
            examDataService.addExamDataLogs(conductedExamDTO);
            return ResponseEntity.ok().body("Successfully conducted the exam and saved the data to DB");
        } catch (Exception e) {
            e.printStackTrace(); // Add this line to print the stack trace
            return ResponseEntity.internalServerError().body("Error:\n" + e.getMessage());
        }
    }
}
