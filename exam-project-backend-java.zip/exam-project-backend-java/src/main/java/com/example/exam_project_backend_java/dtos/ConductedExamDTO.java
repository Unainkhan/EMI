package com.example.exam_project_backend_java.dtos;

import com.example.exam_project_backend_java.entities.ConductedExamData;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConductedExamDTO {

    private String examCode;
    private String examName;
    private ZonedDateTime assignedStartDateTime;
    private ZonedDateTime actualStartDateTime;
    private ZonedDateTime assignedEndDateTime;
    private ZonedDateTime actualEndDateTime;
    private String totalTime;
    private Integer totalStudentsAppeared;
    private String reasonOfStoppingExam;
    private String reasonOfChangingEndTime;
    private Boolean wasTimeExtended;
    private Boolean was30MinuteRuleImplemented;
    private String additionalRules;
    private String basicRules;
    private String combinedRules;
    private String teacherName;
    private String stopExamReason;

    public static ConductedExamData convertToEntity(ConductedExamDTO conductedExamDTO) {
        ConductedExamData conductedExamData = new ConductedExamData();
        conductedExamData.setExamCode(conductedExamDTO.getExamCode());
        conductedExamData.setExamName(conductedExamDTO.getExamName());
        conductedExamData.setAssignedStartDateTime(conductedExamDTO.getAssignedStartDateTime());
        conductedExamData.setActualStartDateTime(conductedExamDTO.getActualStartDateTime());
        conductedExamData.setAssignedEndDateTime(conductedExamDTO.getAssignedEndDateTime());
        conductedExamData.setActualEndDateTime(conductedExamDTO.getActualEndDateTime());
        conductedExamData.setTotalTime(conductedExamDTO.getTotalTime());
        conductedExamData.setTotalStudentsAppeared(conductedExamDTO.getTotalStudentsAppeared());
        conductedExamData.setReasonOfStoppingExam(conductedExamDTO.getStopExamReason());
        conductedExamData.setReasonOfChangingEndTime(conductedExamDTO.getReasonOfChangingEndTime());
        conductedExamData.setWasTimeExtended(conductedExamDTO.getWasTimeExtended());
        conductedExamData.setWas30MinuteRuleImplemented(conductedExamDTO.getWas30MinuteRuleImplemented());
        conductedExamData.setAdditionalRules(Collections.singletonList(conductedExamDTO.getAdditionalRules()));
        conductedExamData.setBasicRules(Collections.singletonList(conductedExamDTO.getBasicRules()));
        conductedExamData.setCombinedRules(Collections.singletonList(conductedExamDTO.getCombinedRules()));
        conductedExamData.setTeacherName(conductedExamDTO.getTeacherName());
        return conductedExamData;
    }
}

