package com.example.exam_project_backend_java.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "CONDUCTED_EXAM_DATA")
public class ConductedExamData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "EXAM_CODE")
    private String examCode;

    @Column(name = "EXAM_NAME")
    private String examName;

    @Column(name = "ASSIGNED_START_DATE_TIME")
    private ZonedDateTime assignedStartDateTime;

    @Column(name = "ACTUAL_START_DATE_TIME")
    private ZonedDateTime actualStartDateTime;

    @Column(name = "ASSIGNED_END_DATE_TIME")
    private ZonedDateTime assignedEndDateTime;

    @Column(name = "ACTUAL_END_DATE_TIME")
    private ZonedDateTime actualEndDateTime;

    @Column(name = "TOTAL_TIME")
    private String totalTime;

    @Column(name = "TEACHER_NAME")
    private String teacherName;

    @Column(name = "TOTAL_STUDENTS_APPEARED")
    private Integer totalStudentsAppeared;

    @Column(name = "REASON_OF_STOPPING_EXAM")
    private String reasonOfStoppingExam;

    @Column(name = "REASON_OF_CHANGING_END_TIME")
    private String reasonOfChangingEndTime;

    @Column(name = "WAS_TIME_EXTENDED")
    private Boolean wasTimeExtended;

    @Column(name = "WAS_30_MINUTE_RULE_IMPLEMENTED")
    private Boolean was30MinuteRuleImplemented;

    @ElementCollection
    @CollectionTable(name = "ADDITIONAL_RULES", joinColumns = @JoinColumn(name = "EXAM_ID"))
    @Column(name = "RULE")
    private List<String> additionalRules;

    @ElementCollection
    @CollectionTable(name = "BASIC_RULES", joinColumns = @JoinColumn(name = "EXAM_ID"))
    @Column(name = "RULE")
    private List<String> basicRules;

    @ElementCollection
    @CollectionTable(name = "COMBINED_RULES", joinColumns = @JoinColumn(name = "EXAM_ID"))
    @Column(name = "RULE")
    private List<String> combinedRules;
}
