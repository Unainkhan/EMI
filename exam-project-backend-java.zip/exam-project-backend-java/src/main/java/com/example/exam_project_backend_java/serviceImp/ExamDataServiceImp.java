package com.example.exam_project_backend_java.serviceImp;

import com.example.exam_project_backend_java.dtos.ConductedExamDTO;
import com.example.exam_project_backend_java.entities.ConductedExamData;
import com.example.exam_project_backend_java.repositories.ExamDataRepository;
import com.example.exam_project_backend_java.services.ExamDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ExamDataServiceImp implements ExamDataService {

    @Autowired
    private ExamDataRepository examDataRepository;

    @Override
    public void addExamDataLogs(ConductedExamDTO conductedExamDTO) throws Exception {
        try {
            ConductedExamData conductedExamData = ConductedExamDTO.convertToEntity(conductedExamDTO);
            examDataRepository.save(conductedExamData);
        } catch (Exception e) {
            throw new Exception(e);
        }
    }
}
