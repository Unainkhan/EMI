package com.example.exam_project_backend_java.services;

import com.example.exam_project_backend_java.dtos.ConductedExamDTO;

public interface ExamDataService {

    void addExamDataLogs(ConductedExamDTO conductedExamDTO) throws Exception;
}
