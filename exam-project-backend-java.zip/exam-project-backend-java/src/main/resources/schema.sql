CREATE DATABASE IF NOT EXISTS exam_data_logs;

USE exam_data_logs;

-- You can add your table creation scripts here if needed
